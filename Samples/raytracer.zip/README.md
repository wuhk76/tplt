This is a simple raytracer using tplt. It will show a path of a laser beam that reflects in a 20x20 square, which is centered a the orgin.
Simply run the raytracer.py script with python3 in the current folder, and then type the desired x and y coordnates, along with the angle of the intial start point.
The domain and range must be within the square, otherwise it will not reflect.
It should now give a laser beam simulation with changing colors. Have fun!