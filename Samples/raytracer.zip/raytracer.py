import matplotlib.pyplot as plt
from tplt import tplt as t

def square():
    plt.axis('equal')
    t.goto(10 , 0)
    t.down()
    t.left(90)
    t.forward(10 , color ='y')
    t.left(90)
    t.forward(20 , color = 'r')
    t.left(90)
    t.forward(20 , color = 'g')
    t.left(90)
    t.forward(20 , color = 'b')
    t.left(90)
    t.forward(10 , color = 'y')
    t.up()
    t.setheading(0)
    t.home()

c = 0
k = 'k'
square()
t.goto(float(input('x:')) , float(input('y:')))
t.left(float(input('angle:')))
t.down()

while c <= 400:
    plt.pause(1 / 60)
    t.forward(1 / 4 , color = f'{k}')
    p = t.locate()
    if p[0] < -9.75:
        t.setheading(180 - p[2])
        k ='g'
    if p[0] > 9.75:
        t.setheading(180 - p[2])
        k = 'y'
    if p[1] < -9.75:
        t.setheading(-p[2])
        k = 'b'
    if p[1] > 9.75:
        t.setheading(-p[2])
        k = 'r'
    c += 1

plt.show()